#include "HexGrid.h"

AHexGrid::AHexGrid()
{
	PrimaryActorTick.bCanEverTick = false;
}


